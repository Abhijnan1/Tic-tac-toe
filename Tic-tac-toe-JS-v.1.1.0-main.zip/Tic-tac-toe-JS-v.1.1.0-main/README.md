# Tic-tac-toe-JS-v.1.1.0

## 🔰Introduction
1. It is a fun and byte sized game to play with anyone.📱
2. It has a fun and interactive UI for easy vision.👁️
3. Since , everyone has played this game it is easy to play.🤘

## 🔰Features 
1. It is very light and byte sized ⭕️ ❌
2. It has a colourful background for more fun 📘📙📗
3. It displays whose turn is going on ✖️
4. It also displays who won the game ✔️
5. It highlights the winning cells. 🔯🔯🔯

## 🔰How to play ?
1. Download or fork the code.⬇️
2. Or navigate to `https://EzazAA.github.io/Tic-tac-toe-JS-v.1.1.0/`📎
3. Download the `Compressed file TICTACTOEJS.zip`🗃️

## 🔰Contribution
1. contributions are invited.😊

## 🔰Message from the author
1. You can copy it and use it.📎
2. Have fun keep coding.❗️
3. Dont forget to check out my youtube channel - `EzazAA`◀️



